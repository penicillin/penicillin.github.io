// ==UserScript==
// @name         NTKO办公OA优化企业快讯管理页
// @namespace    https://penicillin.github.io/
// @version      0.3
// @description  将标题列表栏由编辑功能改为浏览功能
// @author       Penicillinm
// @match        http://192.168.1.65/SubModule/News/NewsBackList.aspx?*
// @grant        none
// ==/UserScript==

(function() {
    //更换链接
    var node='';
    for(var i=2;i<17;i++){
        node=document.getElementById('gvRegulationsList_ctl'+(i<10?'0'+i:i)+'_lbltitle');
        node.innerHTML=node.innerHTML.replace('NewsEdit.aspx','NewsDetail.aspx').replace('action=edit','');
        node.parentNode.nextSibling.innerHTML=node.parentNode.nextSibling.innerHTML.trim()
        node.parentElement.parentElement.firstElementChild.innerHTML=node.parentElement.parentElement.firstElementChild.innerHTML.trim()
    }

    //更改已访问为黑色
    var myStyle = document.createElement('style') //创建div标签
    myStyle.innerHTML="a:visited { color: black; }"
    document.head.appendChild(myStyle)

})();
