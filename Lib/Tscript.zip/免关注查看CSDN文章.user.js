// ==UserScript==
// @name         免关注查看CSDN文章
// @namespace    https://penicillin.github.io/
// @description  一个查看CSDN全文的小工具
// @version      0.1
// @match        https://blog.csdn.net/*
// ==/UserScript==
document.getElementById('article_content').style.height='';
document.getElementsByClassName('hide-article-box hide-article-pos text-center')[0].remove()