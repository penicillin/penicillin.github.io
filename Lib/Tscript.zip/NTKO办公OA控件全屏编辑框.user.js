// ==UserScript==
// @name         NTKO办公OA控件全屏编辑框
// @namespace    https://penicillin.github.io/
// @version      0.2
// @description  扩展编辑框大小
// @match        http://192.168.1.65/SubModule/News/News*
// ==/UserScript==

function URL_Request(strName) {
    var strHref = document.location.toString();
    var intPos = strHref.indexOf("?");
    var strRight = strHref.substr(intPos + 1); //==========获取到右边的参数部分
    var arrTmp = strRight.split("&"); //=============以&分割成数组

    for (var i = 0; i < arrTmp.length; i++) //===========循环数组
    {
        var dIntPos = arrTmp[i].indexOf("=");
        var paraName = arrTmp[i].substr(0, dIntPos);
        var paraData = arrTmp[i].substr(dIntPos + 1);
        if (paraName.toUpperCase() == strName.toUpperCase()) {
            return paraData;
        }
    }
    return "";
}


var EditTable=document.getElementById("Panel_save")||document.getElementById("Panel_send");
if (EditTable != undefined) {
    EditTable.nextSibling.style.width="100%";
}

if(URL_Request('id')!=""){
    var btn = document.createElement("input");
    btn.type = "button";
    btn.className = "u-btn u-btn-c4 u-btn-sm";
    btn.id = "preView";
    btn.value = "预览";
    btn.addEventListener("click",function(){window.open('http://192.168.1.65/SubModule/News/NewsDetail.aspx?id='+URL_Request('id'))})

    var btnPoint=document.getElementById("cmdEdit");
    if (btnPoint != undefined) {
        document.getElementById("cmdEdit").parentNode.appendChild(btn);
    }
}