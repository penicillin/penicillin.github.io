// ==UserScript==
// @name         字体模板
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.font.cn/7.html
// @icon         https://www.google.com/s2/favicons?domain=font.cn
// @grant        none
// ==/UserScript==
document.getElementsByClassName("fonts7")[0].style.backgroundColor = "black";
document.getElementsByClassName("fonts7")[0].style.color = "white";
document.getElementsByClassName("fonts7")[0].style.fontSize = "800px";
document.getElementsByClassName("fonts7")[0].style.lineHeight="1.2em"