// ==UserScript==
// @name         新浪微博展开全文
// @namespace    https://penicillin.github.io/
// @version      0.1
// @description  自动展开隐藏文章部分。
// @match        https://weibo.com/ttarticle/p/show?id=*
// ==/UserScript==
(function() {
document.getElementsByClassName('WB_editor_iframe_new')[0].style.height='auto'
})();