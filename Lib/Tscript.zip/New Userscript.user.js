// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.jietujie.com/wxduihua.html
// @icon         https://www.google.com/s2/favicons?sz=64&domain=jietujie.com
// @grant        none
// ==/UserScript==

(function() {
    //不显示对话数。
    document.getElementsByClassName('i-n-count')[0].style.display='none';
    //不显示旋转图标
    document.getElementsByClassName('rd-common')[1].click();
    //显示用户昵称
    document.getElementsByClassName('rd-common radio-i-b-nick')[1].click();
    //改群名
    document.getElementsByClassName('input-common')[0].value='单车联系通知群（综合办 刘绍相）(7)';
    document.getElementsByClassName('input-common')[0].dispatchEvent(new Event('input')); //触发事件

})();