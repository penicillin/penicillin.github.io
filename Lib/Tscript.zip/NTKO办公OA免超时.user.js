// ==UserScript==
// @name         NTKO办公OA免超时
// @namespace    https://penicillin.github.io/
// @version      0.3.6
// @description  拒绝超时，永久在线。增加提示为管理员帐户功能
// @match        http://192.168.1.65/SubModule/Index.aspx
// ==/UserScript==

function randomHexColor() { //随机生成十六进制颜色
 return '#' + ('00000' + (Math.random() * 0x1000000 << 0).toString(16)).substr(-6);
}

var iframe
try{
    iframe = document.createElement('<iframe></iframe>');
}catch(e){
    iframe = document.createElement('iframe');
}

iframe.src='http://192.168.1.65/SubModule/LeftTree.aspx?DelegataFlag=';
iframe.style.display="none";
document.body.appendChild(iframe);
setInterval(function(){iframe.src='http://192.168.1.65/SubModule/LeftTree.aspx?DelegataFlag='},60000);

//管理员背景色
var admin=document.getElementsByClassName('menuText01')[1];
if (undefined != admin &&admin.innerHTML.search('绍相')<0){
    var adminTip = document.createElement("div");
    adminTip.id = "adminTip";
    adminTip.appendChild(document.createTextNode("注意，当前非为常用帐户")) ;
    adminTip.style.background="red"
    adminTip.style.color="#FFFFFF"
    adminTip.style.position="fixed";
    adminTip.style.top="0px";
    adminTip.style.left="0px";
    adminTip.style.right="0px";
    adminTip.style.margin="0 auto";
    adminTip.style.fontSize='15px';
    adminTip.style.height='21px';
    adminTip.style.width='80%'
    adminTip.style.borderRadius='21px'
    adminTip.style.textAlign='center'
    adminTip.style.fontWeight='bold'
    adminTip.style.zIndex='9999';
    setInterval(function(){adminTip.style.display=new Date().getSeconds()%2==0?"block":"none";},500);
    document.body.appendChild(adminTip);}

//标题菜单不换行;
document.getElementById('lblurl_pnl').replaceWith(document.getElementById('lblurl_pnl').firstChild.nextSibling);
//移除末行版权声明
document.getElementById('footer').remove();
