// ==UserScript==
// @name         NTKO办公OA控件文档转为下载本地
// @namespace    https://penicillin.github.io/
// @version      0.2
// @description  打开文档时自弹出下载框
// @match        http://192.168.1.65/Office/ReadOffice.aspx*
// @match        http://192.168.1.65/OFFICE/ReadOffice.aspx*
// @match        http://192.168.1.65/OFFICE/EditOffice.aspx*
// ==/UserScript==
window.location=document.body.getAttribute('onload').split('"')[1]