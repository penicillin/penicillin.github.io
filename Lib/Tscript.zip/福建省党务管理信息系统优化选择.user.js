// ==UserScript==
// @name         福建省党务管理信息系统优化选择
// @namespace    https://penicillin.github.io/
// @version      0.1
// @description  不做选择直接转到国资委党务系统。
// @match        https://fj.dyejia.cn/pamsso/selPam.jsp
// ==/UserScript==

//window.location.replace('https://fj.dyejia.cn/pamsso/login.jsp?redirect=https%3A%2F%2Fgzpam.dyejia.cn%2Fpam%2Findex.jsp%3FPARTY_LOGIN%3D0');