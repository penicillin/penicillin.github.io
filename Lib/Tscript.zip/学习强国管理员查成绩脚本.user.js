// ==UserScript==
// @name         学习强国管理员查成绩脚本
// @namespace    https://penicillin.github.io/
// @version      0.6
// @description  对日期框做数据同步，并管理隐私开关。
// @author       Penicillinm
// @match        https://study.xuexi.cn/admin/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=xuexi.cn
// @grant        none
// ==/UserScript==

var getDatePane=true;
function GetElementsByExactClassName(someclass) {
    var i, length, elementlist, data = [];
    // Get the list from the browser
    elementlist = document.getElementsByClassName(someclass);
    if (!elementlist || !(length = elementlist.length)){return [];}
    // Limit by elements with that specific class name only
    for (i = 0; i < length; i++) {
        if (elementlist[i].className == someclass){data.push(elementlist[i]);}
    }

    // Return the result
    return data;
}

function listenKeyEven(event) {
    var e = event || window.event || arguments.callee.caller.arguments[0];
    if (e && e.keyCode == 119) { //如果F8键被按下。
        toDo()
    }
}
document.onkeydown=listenKeyEven;

//免超时
var iframe
try{
    iframe = document.createElement('<iframe></iframe>');
}catch(e){
    iframe = document.createElement('iframe');
}
iframe.src='https://study.xuexi.cn/admin/index-admin.html';
iframe.style.display="none";
document.body.appendChild(iframe);
setInterval(function(){iframe.src='https://study.xuexi.cn/admin/index-admin.html'},1000*60*2);

function toDo(){
    if(document.getElementById('tab-detail')!=null && document.getElementById('tab-detail').getAttribute('aria-selected') == 'true'){
        //每页200行
        if (document.getElementsByClassName('el-scrollbar__view el-select-dropdown__list')[3].lastElementChild.className != 'el-select-dropdown__item selected'){
            document.getElementsByClassName('el-scrollbar__view el-select-dropdown__list')[3].lastElementChild.click()
        }

        //移除客服
        if(document.getElementById('drag')!=null){
            document.getElementById('drag').remove();
        }

        //加入自定义的复制按钮
        if(document.getElementById('copyBTN')==null){
            var myBTN = document.createElement('button') //创建div标签
            myBTN.setAttribute('class',"el-button el-button--medium");//定义标签
            myBTN.style.display='inline-block';//设置显示方式
            myBTN.id='copyBTN';
            myBTN.innerHTML="复制表格内容"
            myBTN.onclick=function (){

                // 获取selection对象
                var selection = window.getSelection();
                // 清空selection对象
                selection.removeAllRanges();
                // 创建一个Range实例
                var ele = document.getElementsByClassName('el-table__body')[1]
                var range = new Range();
                range.selectNodeContents(ele);
                // selection对象设置range实例
                selection.addRange(range);
                //复制
                document.execCommand('copy')
            }
            document.getElementsByClassName('el-form-item__content')[3].appendChild(myBTN)
            document.getElementsByClassName('pagination')[1].lastElementChild.appendChild(myBTN)
        }

        //查“隐私”组件:如果找不到“显示”文字则为关，改为开
        if (document.getElementsByClassName('weui-switch')[0].innerHTML.search('显示') ==-1){document.getElementsByClassName('weui-switch')[0].click()};

        //改日期
        if(document.getElementsByClassName('el-range-input')[2].value!=document.getElementsByClassName('el-range-input')[3].value){
            if(getDatePane){
                document.getElementsByClassName('el-range-input')[2].click();
                if(GetElementsByExactClassName('el-date-editor el-range-editor el-input__inner el-date-editor--daterange el-range-editor--medium is-active').length>0&&GetElementsByExactClassName('el-picker-panel el-date-range-picker el-popper')>0){
                    getDatePane=false;
                }

            }
            if(document.getElementsByClassName('el-range-input')[2].value!=document.getElementsByClassName('el-range-input')[3].value){
                document.getElementsByClassName('available in-range end-date')[0]==undefined?console.log('no end-date'):document.getElementsByClassName('available in-range end-date')[0].click()&console.log('0');
            }
        }
         document.getElementsByClassName('el-button el-button--primary el-button--medium')[1].click();
    }
}